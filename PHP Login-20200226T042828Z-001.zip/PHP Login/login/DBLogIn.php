<?php

include_once 'DataBaseConnection.php';

$Usrnm=$_POST['usrnm'];
$Pswd=$_POST['pswd'];
if (empty($Usrnm)|| empty($Pswd)) {
  header("Location: Login%20Form.php?Login=EmptyFields");
  exit();
}else{

  $sql="SELECT * FROM userinfo where UserName=? and Password=? ;";
$stmt=mysqli_stmt_init($conn);
if(!mysqli_stmt_prepare($stmt, $sql)){
    echo "SQL Statement Failed!";
}else{
    mysqli_stmt_bind_param($stmt, "ss", $Usrnm,  $Pswd);
    mysqli_stmt_execute($stmt);
    $result=mysqli_stmt_get_result($stmt);
    while($row=mysqli_fetch_assoc($result)){
        if ($row['UserName']==true && $row['Password']==true) {
          header("Location: Welcome.html?Login:Successfull");
        }else{
          header("Location: Login%20Form.php?Login:Invalid");
        }
    }
}
}
