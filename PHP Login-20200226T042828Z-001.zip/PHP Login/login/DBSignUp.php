<?php
//database connection
include_once 'DataBaseConnection.php';

//getting data from the signupform
$FirstName=mysqli_real_escape_string($conn, $_POST['fn']);
$LastName=mysqli_real_escape_string($conn, $_POST['ln']);
$UserName=mysqli_real_escape_string($conn, $_POST['un']);
$Email=mysqli_real_escape_string($conn, $_POST['email']);
$Password=mysqli_real_escape_string($conn, $_POST['password']);
$CPassword=mysqli_real_escape_string($conn, $_POST['cpassword']);

 //checking if input feilds are empty
    if(empty($FirstName) || empty($LastName) || empty($UserName) || empty($Email) || empty($Password) || empty($CPassword)){
        header("Location: Signup.php?SignUp=EmptyFeilds");
        exit();
    }else if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
            //check if email is valid
           header("Location: Signup.php?SignUp=EmailError");
        exit();
      } elseif($Password!==$CPassword){
            header("Location: Signup.php?SignUp=PasswordCheckFailed&FirstName=".$FirstName."&LastName=".$LastName."&UserName=".$UserName."&Email=".$Email);
            exit();
    }else{
      $sql="select UserName from userinfo where UserName=?";
      $stmt=mysqli_stmt_init($conn);
      if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: Signup.php?SignUp=SQLError");
        exit();
      }else{
        mysqli_stmt_bind_param($stmt, "s", $UserName);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        $resultcheck=mysqli_stmt_num_rows($stmt);
        if ($resultcheck > 0) {
          header("Location: Signup.php?SignUp=UserTaken&FirstName=".$FirstName."&LastName=".$LastName."&Email=".$Email);
          exit();
        }else{
      //sql queries for input data to the table
$sql = "insert into userinfo (FirstName,LastName,UserName,Email,Password) values (?,?,?,?,?);";
    //proceduaral php statements
$stmt=mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
   echo "SQL Error!";
}else{
    //$hashedpwsd=password_hash($Password, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, "sssss", $FirstName, $LastName, $UserName, $Email, $Password);
    mysqli_stmt_execute($stmt);
//relocate to SignUp  form
header("Location: Signup.php?SignUp:Successful");
    exit();
        }
      }
    }
  }
?>
