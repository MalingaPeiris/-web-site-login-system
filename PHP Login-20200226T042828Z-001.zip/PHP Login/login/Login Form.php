<?php
    include_once 'DataBaseConnection.php';
?>

<html>
	<head>
		<title>Login Form</title>
		<link rel="stylesheet" type="text/css" href="Login.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" >
	 </head>
	 <body>
         <form  action="DBLogIn.php" method="POST" name=LoginForm>
		<div class="loginbox">
			<img src="user.png"  class="user">
            <h1>SIGN IN</h1>
            <p>Username <i id="user" class="fa fa-user"></i></p>
			<input type="text" name="usrnm" placeholder="Enter Username" >
            <p>Password</p>
             <input  type="password" name="pswd" placeholder="Enter Password" id="pwinput" ><span class="eye" onclick="showhidepassword()">
                    <i id="hide1" class="fa fa-eye"></i>
                    <i id="hide2" class="fa fa-eye-slash"></i>
                 </span>
			<input type="submit" name="" value="Sign in" ><br>
			<a href="#">Forgot Your Password?</a><br>
			<a href="Signup.php">Don't Have An Account?</a><br>
         </div>
         <script>
             function showhidepassword(){
                 var x=document.getElementById("pwinput");
                 var y=document.getElementById("hide1");
                 var z=document.getElementById("hide2");

                 if(x.type==='password'){
                     x.type="text";
                     y.style.display="block";
                     z.style.display="none";
                 }else{
                     x.type="password";
                     y.style.display="none";
                     z.style.display="block";
                 }
             }
         </script>
         </form>
	 </body>
</html>
