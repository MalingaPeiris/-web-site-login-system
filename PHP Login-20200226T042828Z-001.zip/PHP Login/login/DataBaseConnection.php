<?php

$DBServerName ="localhost";
$DBUserName= "root";
$DBPassword="";
$DBName="login";

$conn=mysqli_connect($DBServerName, $DBUserName, $DBPassword, $DBName);
?>