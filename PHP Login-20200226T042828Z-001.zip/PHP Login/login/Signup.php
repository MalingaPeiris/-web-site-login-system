<html>
    <head>
        <title>SignUp</title>
        <link rel="stylesheet" type="text/css" href="Signup.css"> 
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" >
    </head>
    <body>
        <form action="DBSignUp.php" method="POST">
        <div class="Signupbox">
            <a href="Login%20Form.php">Already Have An Account? </a> <br>
            <h1>Sign Up</h1>
             <p><i id="fn" class="fa fa-user"></i>   First Name </p><br>
            <input type="text" name="fn" placeholder="Enter First Name">
            <p> <i id="ln" class="fa fa-user"></i>   Last Name </p><br>
			<input type="text" name="ln" placeholder="Enter Last Name">
            <p> <i id="un" class="fa fa-user"></i>   User Name </p><br>
			<input type="text" name="un" placeholder="Enter A User Name">
            <br><p> <i id="ln" class="fa fa-calendar"></i>   Date Of Birth </p>
			<select name="dates" id="date">
                <option name="Dates" >Date</option>
                <?php
                    for($i=1;$i<=31;$i++){
                        echo "<option value=".$i.">".$i."</option>";
                    }
                ?>
                
            </select>
            <select class="select" id="month" >
                <option id="m">Month</option>
                <option>January</option>
                <option>February</option>
                <option>March</option>
                <option>April</option>
                <option>May</option>
                <option>June</option>
                <option>July</option>
                <option>August</option>
                <option>September</option>
                <option>October</option>
                <option>November</option>
                <option>December</option>
            </select>
           
            <select name="years" id="year">
                <option name="years" >Year</option>
                <?php
                    for($i=1019;$i<=2019;$i++){
                        echo "<option value=".$i.">".$i."</option>";
                    }
                ?>
                
            </select>
            <br>
            <p><i id="Email" class="fa fa-envelope"></i>   Email </p><br>
            <input  type="email" name="email" placeholder="Enter Email"><br>
            <p><i id="pswd" class="fa fa-key"></i> Password </p>
            <progress   max="100" value="0" id="strength" style="width: 150px"></progress><br>
           <span class="eye" onclick="showhidepassword()">
                    <i id="hide1" class="fa fa-eye"></i>
                    <i id="hide2" class="fa fa-eye-slash"></i>
            </span><br>   <input type="password" name="password" placeholder="Enter a Password ( 8-12 Characters ) " id="pwinput">
            <p><i id="cpswd" class="fa fa-key"></i>  Confirm Password </p><br>
            <input type="password" id="cpwinput" name="cpassword" placeholder="Enter the Password Again ( 8-12 Characters ) "><br>
             
        </div>
            <script type="text/javascript">
             function showhidepassword(){
                 var x=document.getElementById("pwinput");
                 var w=document.getElementById("cpwinput");
                 var y=document.getElementById("hide1");
                 var z=document.getElementById("hide2");
                 
                 if((x.type==='password')&&(w.type==='password')){
                     x.type="text";
                     w.type="text";
                     y.style.display="block";
                     z.style.display="none";
                 }else{
                     x.type="password";
                     w.type="password";
                     y.style.display="none";
                     z.style.display="block";
                 }
             }
                //password strength bar
              var pass=document.getElementById("pwinput")
              pass.addEventListener('keyup',function(){checkpassword(pass.value)
                 })
                function checkpassword(pwinput){
                    var strengthbar =document.getElementById("strength")
                    var strength=0;
                     strengthbar.style.display="block";
                    /*if(pwinput.match(/[a-zA-Z0-9][~<>]+/)){
                        strength +=1;
                    }
                    if(pwinput.match(/[!@#$%^&*()]+/)){
                        strength+=1;
                    }*/
                    var n 
                    for(n=1;pwinput.length>n;n++){
                        strength+=1;
                    }
                    if(pwinput.length>12){
                        alert("The Password Length Must Be Between 8-12 Characters")
                        document.getElementById("pwinput").disabled=true;
                    }
                    switch(strength){
                        case 0:
                            strengthbar.value=12.5;
                            break
                            case 1:
                            strengthbar.value=25;
                            break
                            case 2:
                            strengthbar.value=37.5;
                            break
                            case 3:
                            strengthbar.value=50;
                            break
                            case 4:
                            strengthbar.value=62.5;
                            break 
                            case 5:
                            strengthbar.value=75;
                            break   
                            case 6:
                            strengthbar.value=87.5;
                            break   
                            case 7:
                            strengthbar.value=100;
                            break   
                    }
                    
                }
            </script>
        
        <button  type="submit" name="submit" id="bsignup">SignUp</button>
            </form>
        <a href="Login%20Form.php"><button id="bcancel">Cancel</button></a>
            
        <?php
        if(!isset($_GET['SignUp'])){
            exit();
        }else{
            $signupcheck=$_GET['SignUp'];
            
            if($signupcheck=="Empty"){
                echo "<p class='error'>Please Fill All The Feilds!</p>";
            }else{
                if($signupcheck=="Email"){
                echo "<p class='error' >Please Enter An Valid Email!</p>";
            }else{
                if($signupcheck=="Successful"){
                echo "<p class='error'>SignedUp!</p>";
            }else{
                if($signupcheck=="Successful"){
                echo "<p class='error'>Please ReEnter the Password Again!</p>";
        }
            }
                }
        }
        }
        ?>
    </body>
</html>